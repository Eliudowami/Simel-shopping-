document.addEventListener('DOMContentLoaded', () => {
    // User registration and login
    const registerForm = document.getElementById('register-form');
    const loginForm = document.getElementById('login-form');
    const products = [
        { id: 1, name: 'Tomatoes', category: 'vegetables', price: 50 },
        { id: 2, name: 'Cooking Oil', category: 'oil', price: 150 }
    ];

    registerForm.addEventListener('submit', (event) => {
        event.preventDefault();
        alert('User registered successfully!');
        registerForm.reset();
    });

    loginForm.addEventListener('submit', (event) => {
        event.preventDefault();
        alert('User logged in successfully!');
        loginForm.reset();
    });

    // Product search and filter
    const searchInput = document.getElementById('search');
    const filterSelect = document.getElementById('filter');
    const productList = document.getElementById('product-list');

    searchInput.addEventListener('input', updateProductList);
    filterSelect.addEventListener('change', updateProductList);

    function updateProductList() {
        const searchTerm = searchInput.value.toLowerCase();
        const filterTerm = filterSelect.value;

        const filteredProducts = products.filter(product => {
            const matchesSearch = product.name.toLowerCase().includes(searchTerm);
            const matchesFilter = filterTerm === '' || product.category === filterTerm;
            return matchesSearch && matchesFilter;
        });

        productList.innerHTML = '';
        filteredProducts.forEach(product => {
            const li = document.createElement('li');
            li.textContent = `${product.name} - KSh ${product.price}`;
            productList.appendChild(li);
        });
    }

    updateProductList();

    // Shopping cart
    const cartList = document.getElementById('cart-list');
    const checkoutButton = document.getElementById('checkout-button');
    const cart = [];

    productList.addEventListener('click', (event) => {
        const product = products.find(p => p.name === event.target.textContent.split(' - ')[0]);
        if (product) {
            cart.push(product);
            updateCartList();
        }
    });

    function updateCartList() {
        cartList.innerHTML = '';
        cart.forEach(product => {
            const li = document.createElement('li');
            li.textContent = `${product.name} - KSh ${product.price}`;
            cartList.appendChild(li);
        });
    }

    // Checkout
    const checkoutForm = document.getElementById('checkout-form');
    checkoutForm.addEventListener('submit', (event) => {
        event.preventDefault();
        alert('Payment successful!');
        cart.length = 0;
        updateCartList();
        checkoutForm.reset();
    });
});
